/*
 * JBoss, Home of Professional Open Source.
 * See the COPYRIGHT.txt file distributed with this work for information
 * regarding copyright ownership.  Some portions may be licensed
 * to Red Hat, Inc. under one or more contributor license agreements.
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 */

package com.metamatrix.query.sql.lang;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import com.metamatrix.query.sql.LanguageObject;
import com.metamatrix.query.sql.visitor.SQLStringVisitor;

/**
 * This class represents the criteria clause for a query, which defines
 * constraints on the data values to be retrieved for each parameter in the
 * select clause. <p>
 */
public abstract class Criteria implements LanguageObject {
    
    /**
     * Constructs a default instance of this class.
     */
    public Criteria() {
    }

	/** 
	 * Abstract clone method
	 * @return Deep clone of this criteria
	 */
	public abstract Object clone();
	
    /**
     * Return the parser string.
     */
    public String toString() {
    	return SQLStringVisitor.getSQLString(this);
	}
	
	/**
	 * This utility method will pull apart a tree of criteria by breaking all
	 * compound AND criteria apart.  For instance, ((A=1 AND B=2) AND C=3) 
	 * will be broken into A=1, B=2, C=3.  
	 * @param crit Criteria to break apart
	 * @return List of Criteria, empty list if crit is null
	 */		
	public static List separateCriteriaByAnd(Criteria crit) {
		if(crit == null) { 
			return Collections.EMPTY_LIST;
		}
		
		List parts = new ArrayList();
		separateCriteria(crit, parts);
		return parts;			
	}
    
    public static Criteria combineCriteria(List parts) {
        if(parts == null || parts.isEmpty()) { 
            return null;
        }
        
        if (parts.size() == 1) {
            return (Criteria)parts.get(0);
        }
        
        return new CompoundCriteria(parts);           
    }
	
	/**
	 * Helper method for {@link #separateCriteriaByAnd(Criteria)} that 
	 * can be called recursively to collect parts.
	 * @param crit Crit to break apart
	 * @param parts Collection to add parts to
	 */
	private static void separateCriteria(Criteria crit, Collection parts) {
		if(crit instanceof CompoundCriteria) {
			CompoundCriteria compCrit = (CompoundCriteria) crit;
			if(compCrit.getOperator() == CompoundCriteria.AND) {
				List subCrits = compCrit.getCriteria();
				Iterator iter = subCrits.iterator();
				while(iter.hasNext()) { 
					separateCriteria((Criteria) iter.next(), parts);
				}
			} else {
				parts.add(crit);	
			}
		} else {
			parts.add(crit);		
		}	
	}

	/**
	 * This utility method can be used to combine two criteria using an AND.
	 * If both criteria are null, then null will be returned.  If either is null,
	 * then the other will be returned.  If neither is null and the primaryCrit is
	 * a CompoundCriteria, then the additionalCrit will be added to the primaryCrit
	 * and the primaryCrit will be returned.  If the primaryCrit is not compound, a new
	 * CompoundCriteria will be created and both criteria will be added to it.
	 * @param primaryCrit Primary criteria - may be modified
	 * @param additionalCrit Won't be modified, but will likely be attached to the returned crit
	 * @return Combined criteria
	 */
    public static Criteria combineCriteria(Criteria primaryCrit, Criteria additionalCrit) {
        return combineCriteria(primaryCrit, additionalCrit, false);
    }
    
	public static Criteria combineCriteria(Criteria primaryCrit, Criteria additionalCrit, boolean disjunctively) {
		if(primaryCrit == null) {
			return additionalCrit;
		}
		if(additionalCrit == null) { 
			return primaryCrit;
		}
		CompoundCriteria compCrit = new CompoundCriteria();
		compCrit.setOperator((disjunctively?CompoundCriteria.OR:CompoundCriteria.AND));
		if ((primaryCrit instanceof CompoundCriteria) && ((CompoundCriteria)primaryCrit).getOperator() == (disjunctively?CompoundCriteria.OR:CompoundCriteria.AND)) {
			compCrit.getCriteria().addAll(((CompoundCriteria)primaryCrit).getCriteria());
		} else {
			compCrit.addCriteria(primaryCrit);
		}
		if ((additionalCrit instanceof CompoundCriteria) && ((CompoundCriteria)additionalCrit).getOperator() == (disjunctively?CompoundCriteria.OR:CompoundCriteria.AND)) {
			compCrit.getCriteria().addAll(((CompoundCriteria)additionalCrit).getCriteria());
		} else {
			compCrit.addCriteria(additionalCrit);
		}
		return compCrit;
	}
    
    public static Criteria toDisjunctiveNormalForm(Criteria input) {
        return normalize(input, true);
    }
    
    public static Criteria toConjunctiveNormalForm(Criteria input) {
        return normalize(input, false);
    }
    
    /**
     * Returns a new criteria object in the equivalent normal form to the input.
     *  
     * @param input
     * @return
     */
    static Criteria normalize(Criteria input, boolean dnf) {

        boolean invert = false;
        
        if (input instanceof NotCriteria) {
            NotCriteria not = (NotCriteria)input;
            
            Criteria child = not.getCriteria();
            
            if (child instanceof NotCriteria) {
                return normalize(((NotCriteria)child).getCriteria(), dnf);
            }
            
            if (child instanceof CompoundCriteria) {
                invert = true;
                input = child;
            }
        }
        
        if (!(input instanceof CompoundCriteria)) {
            return input;
        }
        
        CompoundCriteria compCrit = (CompoundCriteria)input;
        
        int operator = compCrit.getOperator();
        
        if (invert) {
            operator = (operator==CompoundCriteria.OR)?CompoundCriteria.AND:CompoundCriteria.OR;
        }
        
        List criteria = new ArrayList(compCrit.getCriteria().size());
        List parts = new LinkedList();
        
        for (Iterator i = compCrit.getCriteria().iterator(); i.hasNext();) {
            Criteria crit = (Criteria)i.next();
            
            if (invert) {
                crit = new NotCriteria(crit);
            }
            
            crit = normalize(crit, dnf);
            
            if (crit instanceof CompoundCriteria) {
                CompoundCriteria child = (CompoundCriteria)crit;
                
                if (operator == child.getOperator()) {
                    criteria.addAll(child.getCriteria());
                    continue;
                } 
                
                if ((dnf && operator == CompoundCriteria.AND) || (!dnf && operator == CompoundCriteria.OR)) {
                    parts.add(child);
                    continue;
                }
            } 

            criteria.add(crit);
        }

        if (parts.isEmpty()) {
            //no expansion needed, just return
            return new CompoundCriteria(operator, criteria);
        }
        
        int total = 1;
        int[] divisors = new int[parts.size()];
        
        for (int i = 0; i < parts.size(); i++) {
            divisors[i] = total;
            total *= ((CompoundCriteria)parts.get(i)).getCriteriaCount();
        }
        
        List newCrits = new ArrayList(total);
        
        for (int i = 0; i < total; i++) {
            CompoundCriteria crit = new CompoundCriteria(dnf?CompoundCriteria.AND:CompoundCriteria.OR, new ArrayList(parts.size() + criteria.size()));
            crit.getCriteria().addAll(criteria);
            for (int j = 0; j < parts.size(); j++) {
                CompoundCriteria disjunct = (CompoundCriteria)parts.get(j);
                
                Criteria part = (Criteria)disjunct.getCriteria().get((i/divisors[j])%disjunct.getCriteriaCount());
                crit.addCriteria(part);
            }
            newCrits.add(crit);
        }
        
        return new CompoundCriteria(!dnf?CompoundCriteria.AND:CompoundCriteria.OR, newCrits);
    }
	
}  // END CLASS
