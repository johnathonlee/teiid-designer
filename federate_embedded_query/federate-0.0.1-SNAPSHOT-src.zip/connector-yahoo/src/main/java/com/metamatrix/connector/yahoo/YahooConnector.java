/*
 * JBoss, Home of Professional Open Source.
 * Copyright (C) 2008 Red Hat, Inc.
 * Copyright (C) 2000-2007 MetaMatrix, Inc.
 * Licensed to Red Hat, Inc. under one or more contributor 
 * license agreements.  See the copyright.txt file in the
 * distribution for a full listing of individual contributors.
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 */

package com.metamatrix.connector.yahoo;

import com.metamatrix.data.api.*;
import com.metamatrix.data.exception.ConnectorException;

/**
 * Starting point for the Loopback connector.
 */
public class YahooConnector implements Connector {

    private ConnectorEnvironment env;
    
    static final ConnectorCapabilities CAPABILITIES = new YahooCapabilities();

    /**
     * 
     */
    public YahooConnector() {
        super();
    }

    /* 
     * @see com.metamatrix.data.Connector#initialize(com.metamatrix.data.ConnectorEnvironment)
     */
    public void initialize(ConnectorEnvironment environment) throws ConnectorException {
        this.env = environment;
    }

    /* 
     * @see com.metamatrix.data.Connector#stop()
     */
    public void stop() {
        // nothing to do
    }

    /* 
     * @see com.metamatrix.data.Connector#start()
     */
    public void start() {
        // nothing to do
    }

    /* 
     * @see com.metamatrix.data.Connector#getConnection(com.metamatrix.data.SecurityContext)
     */
    public Connection getConnection(SecurityContext context) throws ConnectorException {
        return new YahooConnection(env);
    }

}
