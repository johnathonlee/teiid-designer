@javax.xml.bind.annotation.XmlSchema(namespace = "urn:partner.soap.sforce.com", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.sforce.soap.partner;
